<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH C:\Users\aldek\Desktop\portofolio_aldeki\vendor\filament\forms\src\/../resources/views/components/grid.blade.php ENDPATH**/ ?>